function [vector]= foot_silho_main(img)
 %clc;
 %clear all;
 %close all;
%img= imread('C:\Users\RITI\Documents\MATLAB\My Scans\gaurav_r1.jpg');
i_rs2 = imresize(img, .1);
%subplot(2, 3, 1); title('Original Image');
% figure(1);
% imshow(i_rs2);

%%      RBG to Gary to Binary Conversion 

i_gray2= rgb2gray(i_rs2);
bin_img2= im2bw(i_gray2, .32);
 %subplot(2, 3, 2); title('Binary Image');                                                    
%    figure(2); 
%  imshow(bin_img2); title('Binary Image');

%%           Median Filter Apply 

% rotete_image2 = imrotate(bin_img2,0);
% %[r1,c1] = size(rotete_image2);
Fltr_image2 = medfilt2(bin_img2);
%subplot(2, 3, 3); title('Filtered Image');
% figure(3);
% imshow(Fltr_image2);title('Filtered Image');

%%          Edge Detection 

Detected_edge = edge(Fltr_image2,'canny'); %image 2
[r1,c1] = size(Detected_edge);
 %subplot(2, 3,4); 
% title('Datected Edge');
%     figure(4);
%  imshow(Detected_edge);
  
%%          Finding the Connected Component
sz=20;
count2(sz)=0;
Detected_edge = bwlabeln(Detected_edge,8);
for i= 1 : 1: r1
    for j= 1:1:c1
        if (Detected_edge(i,j)~=0);
            count2(Detected_edge(i,j))=count2(Detected_edge(i,j))+1;
        end
    end
end
max=0;
for i= 1 : 1: sz
    if (max < count2(i))
        max = count2(i);
        pos=i;
    end
end
for i= 1 : 1: r1
    for j= 1:1:c1
        if Detected_edge(i,j)~=pos
            Detected_edge(i,j)=0;
        end
    end
end
% figure(5);
% imshow(Detected_edge); title('Connected Component');
BW5= im2bw(Detected_edge);
%subplot(2, 3, 5); 
%title('Biggest connected element');
%figure(6);
%imshow(BW5);
%subplot(2, 3, 6); title('Edge Detection');

%%          finding the contour points

var2=contour(BW5);

%% Fill the image to calculate center of mass 

C2=imfill(BW5,'holes');
%figure(6);imshow(C2); title('Filled Image');
 
 %%         Calculating center of mass and printing it
C2 = bwlabel(C2);
s2 = regionprops(C2, 'centroid');
centroids = cat(1, s2.Centroid);
figure(23); imshow(C2); title('Center of Mass'); 
 hold on
 plot(centroids(:,1), centroids(:,2), 'b*')
 hold off
centroids1= centroids';
%% Find the distence from centroid to contour points
[r_var2, c_var2]= size(var2);
%centroids2=zeros(r_var2,c_var2);
for j= 1:1: c_var2 
    %for i= 1: 1: r_var2
        centroids1(:,j)= centroids1(:,1);
         %centroids1(i,j)= var2(i,j)- centroids1(i,j);
    % end
 end

        centroids2 = var2 - centroids1;
        
    


 %% Creating Vector of contour points.
 var12 = var2';
 v12= var12(:,1,end);
 v22= var12(:,2,end);
 windowSize = 4;
 x12 = filter(ones(1,windowSize)/windowSize,1,v12);
 y12 = v12(1:4 :end); 
 x22 = filter(ones(1,windowSize)/windowSize,1,v22);
 y22 = v22(1:4 :end);
 var_up2 = [];
 var_up2(:,1,end)= y12;
 var_up2(:,2,end)= y22;
 var_up2= var_up2';
 sz2= size(var_up2); 
 num2=sz2(1)*sz2(2);
 
 var_vec2=zeros(1,num2);

% for i=1:sz2(1)
% 
% for j=1:sz2(2)
% 
% var_vec2(1,(i-1)*sz2(2)+j)=var_up2(i,j);
% 
% end
% 
% end
%var_up_single= im2single(var_up2');

cov_var2= cov(var_up2);
[COEFF,latent,explained] = pcacov(cov_var2);
%figure(7);
%subplot(2, 3, 6); 
%title('Covariance Plot');
% hold on
% plot(COEFF(1,:), '*b')
% hold off
vector= COEFF(1:50);
end

%% Creating bounding box 

%C2=imfill(BW4,'holes');
%figure(6);imshow(C2); title('Filled Image');
%se2 = strel('disk',3);
%C2 = imdilate(C2,se2);
%C2 = imerode(C2,se2);
%C2 = imerode(C2,se2);
%C2=imdilate(C2,se2);
%figure(31);imshow(BW4);
%CC2=bwconncomp(C2);

%figure(32);imshow(CC2);
% s3  = regionprops(CC2,'BoundingBox');
% bb3 = s3(1).BoundingBox;
% x1_2 = insertShape(C2,'Rectangle',bb3); 
% figure(11); imshow(x1_2);

%figure,imshow(x1);title('Bounding Box in Image');

%% Crop the bounded region

% [r2,c2]= size(C2);
% bin_img2= im2bw(C2, .32);
% s22 = regionprops(bin_img2,'Image');
% bimage2 = s22.Image;
% figure(13),imshow(bimage2);
% title('Significant Image')

%% Edge Detection 

%BW2 = edge(C2,'canny');
%subplot(2, 3, 5); title('Edge Detection');
%figure(6);imshow(BW2); title('Detected Edge');

% %% computing centriod of image
% 
% cent = regionprops(bimage,'Centroid');
% cent_img = cent.Centroid;
% figure;imshow(bimage);
% hold on
% plot(centroids(:,1), centroids(:,2), 'r*')
% hold off
% %figure; imshow(x1);

%%         Calculating center of mass and printing it

% s2 = regionprops(bimage2, 'centroid');
% centroids = cat(1, s2.Centroid);
% figure(23); imshow(bimage2); title('Center of Mass'); 
% hold on
% plot(centroids(:,1), centroids(:,2), 'b*')
% hold off

   
%% Finding the contour points

% 
%  %var2=contour(BW5);
%  var2=BW5;
%  %figure(7); imshow(var2); title('asdbhj');
%  %var1=(var(:,1), var(:,2));
%   hold on
%   plot(var2(1,:), var2(2,:), 'b*')
%   hold off
%  var12 = var2';                                                                                                                 
%  mu12  =  mean(var12,1);
%  [r_var2, c_var2]= size(var12);
%  for i= 1: 1: r_var2
%      for j= 1:1: c_var2
%          mu12(i,j)= mu12(1,1);
%          var12(i,j)= var12(i,j)- mu12(i,j);
%      end
%  end
% 
% %var1 = var1 - repmat(mu1,length(var1),1);
% 
%  var22 = var12';
%  v12= var12(:,1,end);
%  v22= var12(:,2,end);
%  windowSize = 16;
%  x12 = filter(ones(1,windowSize)/windowSize,1,v12);
%  y12 = v12(1:16 :end); 
%  x22 = filter(ones(1,windowSize)/windowSize,1,v22);
%  y22 = v22(1:16 :end);
%  var_up2 = [];
%  var_up2(:,1,end)= y12;
%  var_up2(:,2,end)= y22;
%  
%  sz2= size(var_up2); 
%  num2=sz2(1)*sz2(2);
%  
%  var_vec2=zeros(1,num2);
% 
% for i=1:sz2(1)
% 
% for j=1:sz2(2)
% 
% var_vec2(1,(i-1)*sz2(2)+j)=var_up2(i,j);
% 
% end
% 
% end
% vector= var_vec2;


%var_vec_sin= logical(var_vec);
%dis = dtw(var_vec, var_vec);
% covx = cov(var_up');
% [v,d] = eig(var_up*var_up');
% figure(3); clf;
% plot(var1(:,1),var1(:,2),'b.');% centered data
% corltn=corrcov(covx);
%plot(d);
%plot(v(:,1)

%%  moments
%dbimage = double(bimage); 
%m = moment(bimage,7)

%[val_mom2] = feature_vec(bimage);
% tbimage = bimage*val_mom2(1,1);
% mbimage = bimage*val_mom2(2,1);
% mbimage = bimage*val_mom2(2,1);
% mbimage = bimage*val_mom2(2,1);
% figure; imshow(tbimage);
% figure; imshow(mbimage);
%m = moments_c(bimage);

%% %% Principal cmponent anaysis using covariance matrix
% covx = cov(var);
% %COEFF = pcacov(covx);
% [COEFF,latent,explained] = pca(bimage);
%  single_cof_vector=[];
%  [cr,cl]= size(COEFF);
%  ind =1;



% hold on
 
 %hold off
% [Label,Total]=bwlabel(C,8);
% %Object Number
% num=1;
% [row, col] = find(Label==num);
% row1 = min(row);
% %row2 = max(row);
% col1 = min(col);
% row2 = max(col);
% sx= col1-0.5;
% sy= row1-0.5;
% %breadth=max(col)-(col1);
% len=(row2-row1)+1;
% BBox=[sx sy breadth len];
% display(BBox);
% %Refer:http://angeljohnsy.blogspot.in/2011/06/how-to-draw-in-matlab.html
% figure,imshow(I);
% hold on;
% x=zeros([1 5]);
% y=zeros([1 5]);
% x(:)=BBox(1);
% y(:)=BBox(2);
% x(2:3)=BBox(1)+BBox(3);
% y(3:4)=BBox(2)+BBox(4);
% plot(x,y);
% 
% % 
% % mylabel2 = double(X);
% % image = defaultSegment(Fltr_image);
% % clear s;
% % s = regionprops(image, 'Area', 'BoundingBox');
% % numObj = numel(s);
% % index = 1;
% % for k = 1: numObj-1
%     if s(k+1).Area > s(index).Area
%         index = k+1;
%     else
%         index = index;
%     end
% end
% figure, imshow(input_image);
% rectangle('Position',s(index).BoundingBox);
% boundImage = null;
% 


%length(fltr_image);

% boundaries = bwboundaries(Fltr_image);
% %figure;imshow(boundaries);
% x = boundaries(:, 1);
% y = boundaries(:, 2);
% maxDistance = -inf;
% for index1 = 1 : length(x)
%   for index2 = 1 : length(y)
%     deltaX = x(index1) - x(index2);
%     deltaY = y(index1) - y(index2);
%     distance = sqrt(deltaX^2+deltaY^2);
%     if distance > maxDistance
%     end
%   end
% end
% 
% subplot(2, 2, 2); title('Edge Detection');
% BW2 = edge(k,'canny');
%subplot(2, 2, 2); title('Edge Detection');
%imshow(B);
% SE = strel('line',5,90);
% I2 = imdilate(BW2,SE);
% subplot(2, 2, 3); title('Connected Edges');
% imshow(I2);
% %con = bwconncomp(I2);
% I2(end, :) = true;
% % The arm is sealed off. Now we can fill.
% I2= imfill(I2, 'holes');
% % There are small noise blobs.  Extract the largest one.
% I2 = bwareafilt(I2, 1);
% I2(end,:) = false;
% % Display the image.
% subplot(2, 2, 4);
% title('Filled Binary Image', 'FontSize', 9, 'Interpreter', 'None');
% imshow(I2);

%imshow(con);
% %fill = imfill(I2);
% %figure; imshow(I3);
% %
% %figure; imshow(fill);
% % rc= size(i_gray);
% % X = zeros(size(rc));
% % for i= 1:1: r
% %     for j= 1:1: c
% %     X(r,c)= i_gray(r,c);
% %     end
% % end
% % 
% % BW = imbinarize(intArray);
% % imshow(BW);
