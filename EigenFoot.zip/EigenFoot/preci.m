clear all;
close all;
t= [2 4 6 8 10 12 14 16 18 20];
%t = [13 12 11 10 9 8 7 6 5 4 3.5 3 2.5 2 1.5 1 .5];
recall= [0.3888888889 0.5555555556 0.6666666667 0.7222222222 0.7777777778 0.7777777778 0.9444444444 0.9444444444 1 1];
prec = [1 1 1 1 1 1 0.9444444444 0.7083333333 0.6 0.5454545455];

k=plot(t,recall, 'LineWidth', 2);
legend('Recall')
hold on;
h=plot(t,prec, 'LineWidth', 2);
legend('Precision')

%figure(2); plot(t,recall,'-ro',t,prec,'-.b')
legend('Recall', 'Precision')
title('Precision-Recall vs Thresholds Plot for Finding Optimal Threshold')
xlabel('Threshold')
ylabel('Precision-Recall')